import sqlite3
from PyQt5.QtWidgets import QApplication, QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox
from PyQt5.QtGui import QIcon

# Create a SQLite database connection
conn = sqlite3.connect('todo.db')
cursor = conn.cursor()

# Create a Users table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT NOT NULL,
        password TEXT NOT NULL
    )
''')
conn.commit()

class RegistrationDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Register")
        self.setGeometry(400, 200, 500, 250)  # Adjusted size and centered position

        layout = QVBoxLayout()

        # Set background image using a stylesheet
        self.setStyleSheet("background-image: url('images/bak_com.jpg'); background-repeat: no-repeat; background-position: center;")

        self.username_label = QLabel("Username:")
        self.username_label.setStyleSheet("font-family: Century Gothic; font-size: 16px; color: white;")  # Century Gothic font and larger font
        self.username_input = QLineEdit()
        self.username_input.setStyleSheet("font-family: Century Gothic; font-size: 16px;")  # Century Gothic font and larger font

        self.email_label = QLabel("Email:")
        self.email_label.setStyleSheet("font-family: Century Gothic; font-size: 16px; color: white;")  # Century Gothic font and larger font
        self.email_input = QLineEdit()
        self.email_input.setStyleSheet("font-family: Century Gothic; font-size: 16px;")  # Century Gothic font and larger font

        self.password_label = QLabel("Password:")
        self.password_label.setStyleSheet("font-family: Century Gothic; font-size: 16px; color: white;")  # Century Gothic font and larger font
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet("font-family: Century Gothic; font-size: 20px;")  # Century Gothic font and larger font

        self.register_button = QPushButton("Register")
        self.register_button.clicked.connect(self.try_register)

        # Add padding inside the layout
        layout.setContentsMargins(60, 60, 60, 60)

        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.email_label)
        layout.addWidget(self.email_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.register_button)

        self.setLayout(layout)

    def try_register(self):
        # Get user input
        username = self.username_input.text()
        email = self.email_input.text()
        password = self.password_input.text()

        # Check if username already exists
        cursor.execute('SELECT * FROM Users WHERE username = ?', (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            QMessageBox.critical(self, 'Registration Failed', 'Username already exists. Please choose a different one.')
        else:
            # Insert new user into the database
            cursor.execute('INSERT INTO Users (username, email, password) VALUES (?, ?, ?)', (username, email, password))
            conn.commit()

            QMessageBox.information(self, 'Registration Successful', 'User registered successfully. Please login.')
            self.accept()

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Login")
        self.setGeometry(400, 200, 500, 250)  # Adjusted size and centered position

        layout = QVBoxLayout()

        # Set the application icon
        self.setWindowIcon(QIcon("images/calender.png"))

        # Set background image using a stylesheet
        self.setStyleSheet("background-image: url('images/bak_com.jpg'); background-repeat: no-repeat; background-position: center;")

        self.username_label = QLabel("Username:")
        self.username_label.setStyleSheet("font-family: Century Gothic; font-size: 16px; color: white;")  # Century Gothic font and larger font
        self.username_input = QLineEdit()
        self.username_input.setStyleSheet("font-family: Century Gothic; font-size: 16px;")  # Century Gothic font and larger font

        self.password_label = QLabel("Password:")
        self.password_label.setStyleSheet("font-family: Century Gothic; font-size: 16px; color: white;")  # Century Gothic font and larger font
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet("font-family: Century Gothic; font-size: 20px;")  # Century Gothic font and larger font

        self.login_button = QPushButton("Login")
        self.login_button.clicked.connect(self.try_login)

        # Add padding inside the layout
        layout.setContentsMargins(60, 60, 60, 60)

        # Create a horizontal layout for login and register buttons
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.login_button)

        # Add a "Register" button
        register_button = QPushButton("Register")
        register_button.clicked.connect(self.show_register_form)
        button_layout.addWidget(register_button)

        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addLayout(button_layout)

        self.setLayout(layout)

    def try_login(self):
        # Get user input
        username = self.username_input.text()
        password = self.password_input.text()

        # Check if the user exists
        cursor.execute('SELECT * FROM Users WHERE username = ? AND password = ?', (username, password))
        existing_user = cursor.fetchone()

        if existing_user:
            self.accept()
        else:
            QMessageBox.critical(self, 'Login Failed', 'Invalid username or password.')

    def show_register_form(self):
        register_dialog = RegistrationDialog()
        if register_dialog.exec_() == QDialog.Accepted:
            print("Registration successful!")
        else:
            print("Registration canceled.")

if __name__ == '__main__':
    import sys
    from PyQt5.QtWidgets import QApplication
    from main import Root  # Import your main application class

    app = QApplication(sys.argv)

    login_dialog = LoginDialog()

    # Centering the dialog on the screen
    desktop = app.desktop()
    rect = desktop.availableGeometry()
    login_dialog.move(int((rect.width() - login_dialog.width()) / 2), int((rect.height() - login_dialog.height()) / 2))

    if login_dialog.exec_() == QDialog.Accepted:
        # If login successful, launch the main application
        main_window = Root()
        main_window.show()

        sys.exit(app.exec_())

